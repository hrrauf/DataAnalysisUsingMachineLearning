These .py files scrape data about job from Amazon Career, Facebook Career and Google Career websites.

This is a website scraper to scrape job search results from Amazon, Facebook and Google. 
It may take certain hours to scrape all the jobs from all the websites but it works without crashing, at least at the time of this entry.

These codes will create separate CSV file for each company.
