These codes generate pie charts about job category in Amazon, Facebook and Google dataset.

The formats of data about job category in three .csv files are kinds of different, so I use different codes to preprocess these data.

These three .py files will create separate pie charts for each corresponding company respectively.
