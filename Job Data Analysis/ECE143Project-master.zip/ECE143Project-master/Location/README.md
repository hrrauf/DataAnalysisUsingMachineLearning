These codes will generate three different graphs about Location in Amazon, Facebook and Google dataset, including a bar graph for Top10 Popular US City, a bar graph for Top10 Overseas Workplace and one heat map in terms of States.

The formats of data about Location in three .csv files are kinds of different, so I use different codes to preprocess these data.

Each .py file will create a bar graph for Top10 Popular US City, a bar graph for Top10 Overseas Workplace and a heat map in terms of States for its corresponding company.
