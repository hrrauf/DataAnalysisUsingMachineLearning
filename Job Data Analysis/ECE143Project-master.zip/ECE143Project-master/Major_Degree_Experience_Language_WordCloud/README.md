Functions to get preferred majors, programming languages, degrees, experience years and technical skills from 3 dataset and draw related figures.
